<ul>
  <li><a href="/">Home</a><li>
  <li><a href="/Classic">Classic</a><li>
  <li><a href="/sports">Sports</a><li>
  <li><a href="/SUV">SUV</a><li>
  <li><a href="/trucks">Trucks</a><li>
  <li><a href="/used">Used</a><li>
</ul>
