<?php
function checkEmail($clientEmail){
    $valEmail = filter_var($clientEmail, FILTER_VALIDATE_EMAIL);
 return $valEmail;
}

function checkPassword($clientPassword){
    $pattern = '/^(?=.*[[:digit:]])(?=.*[[:punct:]\s])(?=.*[A-Z])(?=.*[a-z])(?:.{8,})$/';
 return preg_match($pattern, $clientPassword);
}

function checkClassificationName($classificationName){
    $pattern = '/^(?:.{1,30})$/';
 return preg_match($pattern, $classificationName);
}

function navBuild($classifications){
    $navList = '<ul>';
    $navList .= "<li><a href='/phpmotors/index.php' title='View the PHP Motors home page'>Home</a></li>";
    foreach ($classifications as $classification) {
        $navList .= "<li><a href='/phpmotors/vehicles/?action=classification&classificationName=".urlencode($classification['classificationName'])."' 
        title='View our $classification[classificationName] product line'>$classification[classificationName]</a></li>";
    }
    $navList .= '</ul>';
    return $navList;
}

// Build the classifications select list 
function buildClassificationList($classifications){ 
    $classificationList = '<select name="classificationId" id="classificationList">'; 
    $classificationList .= "<option>Choose a Classification</option>"; 
    foreach ($classifications as $classification) { 
     $classificationList .= "<option value='$classification[classificationId]'>$classification[classificationName]</option>"; 
    } 
    $classificationList .= '</select>'; 
    return $classificationList; 
}

function buildVehiclesDisplay($vehicles){
    $dv = '<ul id="inv-display">';
    foreach ($vehicles as $vehicle) {
     $dv .= "<li class='display-info'><a href='/phpmotors/vehicles/?action=vehicleDetail&invId=$vehicle[invId]'>";
     $dv .= "<img class='car-img' src='$vehicle[invThumbnail]' alt='Image of $vehicle[invMake] $vehicle[invModel] on phpmotors.com'>";
     $dv .= '<hr>';
     $dv .= "<h2>$vehicle[invMake] $vehicle[invModel]</h2>";
     $dv .= "<span>$$vehicle[invPrice]</span>";
     $dv .= '</a></li>';
    }
    $dv .= '</ul>';
    return $dv;
   }

    //bud vehicle details wrapped up in HTML
    Function buildDetailDisplay($vehicleInfo){

    $dd = "<div class='imgColumn'><div class='image-details'><img src='$vehicleInfo[invImage]' alt= 'Image of $vehicleInfo[invMake] $vehicleInfo[invModel]'></div>";
    $dd .= "<h3 class='price'>Price: $$vehicleInfo[invPrice]</h3></div>";
    $dd .= "<div class='infoColumn'><h3 class=''>$vehicleInfo[invMake] $vehicleInfo[invModel] Details</h3>";  
    $dd .= "<p class='description'>$vehicleInfo[invDescription]</p>";
    $dd .= "<p class='color'>Color: $vehicleInfo[invColor]</p>"; 
    $dd .= "<p class='stock'># in Stock: $vehicleInfo[invStock]</p></div>"; 
    return $dd;
}
?>